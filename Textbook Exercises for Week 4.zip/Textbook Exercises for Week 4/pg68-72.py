Python 3.10.4 (tags/v3.10.4:9d38120, Mar 23 2022, 23:13:41) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
for exponent in range(7, 11):
        print(exponent, 10 ** exponent)

        
7 10000000
8 100000000
9 1000000000
10 10000000000
salary = 100.00
print("Your salary is $" + str(salary))
Your salary is $100.0
salary = 100.00
print("Your salary is $%0.2f" % (salary)



"%6.3f" % 3.14
      
SyntaxError: '(' was never closed
print("Your salary is $%0.2f" % (salary))
      
Your salary is $100.00
"%6.3f" % 3.14
      
' 3.140'

================================ RESTART: Shell ================================
for exponent in range(7, 11):
      print("%-3d%12d" % (exponent, 10 ** exponent))

      
7      10000000
8     100000000
9    1000000000
10  10000000000
salary = 100.00
      
print("Your salary is $" + str(salary))
      
Your salary is $100.0
salary = 100.00
      
print("Your salary is $%0.2f" % (salary)






      