Python 3.10.4 (tags/v3.10.4:9d38120, Mar 23 2022, 23:13:41) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
number=2
exponent=3
product=1
for eachPass in range(exponent):
        product = product * number
        print(product, end = " ")

2 4 8 
product
8
for count in range(4):
        product = product * (count + 1 )

        
product
192
product=1
for count in range(4)
        product = product * (count + 1)
        
SyntaxError: expected ':'
for count in range(4):
        product = product * (count + 1)

        
product
24

================================ RESTART: Shell ================================
product =1
for count in range(1, 5):
         product = product * count

         
product
24
lower = int(input("Enter the lower bound: "))
Enter the lower bound: 1
upper = int(input("Enter the lower bound: "))
Enter the lower bound: 10
theSum=0
for number in range(lower, upper + 1):
        theSum = theSum + number

theSum
55

================================ RESTART: Shell ================================
 for count in range(1,4):
     
SyntaxError: unexpected indent
for count in range(1,4):














    