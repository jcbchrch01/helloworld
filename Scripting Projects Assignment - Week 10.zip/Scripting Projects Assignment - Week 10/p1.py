import turtle

#This part defines the cirlce in the Turtle module
def drawCircle (centerpoint, radius):
	(x,y) = centerpoint
	turtle.up()
	turtle.setpos(x,y)
	turtle.down()
	turtle.circle(radius)
#This prints what the radius and circumference is of the circle
	print("The radius of the circle is", radius)
	print("The circumference of the circle is",(2.0 * 3.14 * radius))
#Draws the circle defined
drawCircle((20,20), 20)
