def isSorted(stuff):    
    for i in range(1,len(stuff)):
        if stuff[i - 1] > stuff[i]:
           return False
    return True

numbers = [1, 2, 3, 4, 5, 6, 7]

print(isSorted(numbers))
