from turtle import Turtle
t = Turtle()

t.width(2)
t.left(90)
t.forward(30)
t.left(90)
t.up()
t.forward(10)
t.setheading(0)
t.pencolor("red")
t.down()
t.forward(20)
t.hideturtle()
