base = int(input("Enter the base: "))
height = int(input("Enter the height: "))
area = .5 * base * height
print("the area is", area, "Square units.")
