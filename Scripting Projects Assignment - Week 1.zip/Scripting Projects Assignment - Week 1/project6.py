radius = int(input("Enter the radius: "))
area = 3.14 * radius ** 2
print("the area is", area, "Square units.")
