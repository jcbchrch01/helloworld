width = int(input("Enter the width: "))
height = int(input("Enter the height: "))
area = width * height
print("the area is", area, "Square units.")
