year = 365
hours = 24 * year
minutes = hours * 60
seconds = minutes * 60
#calculates light speed
lightSpeed = 3 * 10*8
lightYearD = lightSpeed * seconds
#display light speed
print("Light travels" + str(lightYearD) + "meters in a year.")
