def displayRange(lower, upper):
    while lower<= upper:
        print(lower)
        lower = lower + 1
