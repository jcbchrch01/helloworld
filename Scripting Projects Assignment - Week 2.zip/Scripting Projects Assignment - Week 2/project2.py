l=float (input("Length:"))
print ("Surface area of a cube is ", 6*l*l)
