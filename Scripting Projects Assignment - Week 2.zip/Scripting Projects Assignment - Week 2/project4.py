import math
r=int(input("enter the radius of sphere "))
d= 2*r 
c= d*math.pi 
s_a= 4*math.pi*(r**2) 
v= (4/3)*math.pi*(r**3)
print("Diameter   :",d)
print("Circumference    :",c)
print("Surface area   :",s_a)
print("Volume   :",v)

