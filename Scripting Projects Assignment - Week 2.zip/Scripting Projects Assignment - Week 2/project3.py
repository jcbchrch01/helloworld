new=int(input("How many new movies?:"))
old=int(input("How many old movies?:"))
total=(new * 3.00)+(old * 2.00)
print("The total is","$",total)

