x = int(input("Enter the first side: "))
y = int(input("Enter the second side: "))
z = int(input("Enter the third side: "))
if x==y and y==z:
    print("\nThe triangle is equilateral.")
else:
    print("\nThe triangle is not equilateral.")
