first = int(input("Enter the first number: "))
second = int(input("Enter the second number: "))
print("Maximum:", max(first,second))
print("Minimum:", min(first,second))
