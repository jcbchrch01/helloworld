x = 5
def f():
    x = 10
f()
print(x)
