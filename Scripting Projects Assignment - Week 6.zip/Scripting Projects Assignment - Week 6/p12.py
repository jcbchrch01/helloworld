#file name
filename = input("Enter the file name: ")
#opening
file = open(filename)
#header
print("{0:18s}".format("\nName"), "{0:11s}".format("Hours"), "{0:s}".format("Total Pay"))
#for each line
for line in file:
   line = line.split()
   #sets name as first value 
   name = line[0]
   #sets hours as second 
   hours = int(line[1])
   #sets wage as last 
   wage = float(line[2])
   #total pay
   totalPay = hours * wage
   #output
   print("{0:11s}".format(name), "{0:11d}".format(hours), "{0:15.2f}".format(totalPay))
  
