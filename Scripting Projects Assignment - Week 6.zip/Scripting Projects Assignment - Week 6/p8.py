#enter the file1 which is input file
infile=input("enter the input filename with extension ");
#enter the file2 which is output file
outfile=input("enter the output filename with extension ");
#opening the file1
f1=open(infile,"r");
#opening the file2
f2=open(outfile,"w+");

content=f1.read();

f2.write(content);

f1.close();
f2.close();
