#Request input
codedText = input("Enter the coded text: ")
distanceValue = int(input("Enter the distance value: "))
#Calculate decrypt
plainText = ""
for ch in codedText:
    ordvalue = ord(ch)
    cipherValue = ordvalue - distanceValue
    plainText += chr(cipherValue)
print(plainText)
